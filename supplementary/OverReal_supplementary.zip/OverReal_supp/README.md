# OverReal: supplementary material

Anonymous supplementary material for "Over-realization in text-to-image
generation" (OverReal). Everything here is text: prompts, labels, judge
outputs, metric scores, generation manifests and code. Images are hosted
separately (link in the paper's reproducibility statement at camera-ready);
the images of the open-weight generators can be regenerated exactly from
`data/manifests/` (model, seed, steps, cfg).

## data/

- `overreal_gen/prompts.jsonl`: OverReal-Gen, 698 prompt-target pairs with
  family and cue type. `expanded_prompts.jsonl`: the expanded split (Qwen-Image
  rewriter and Ideogram Magic Prompt). `wild_prompts.jsonl`: the in-the-wild
  set (397 prompts from DiffusionDB and Pick-a-Pic, with source, cue and
  family). `rewrite_target_treatment.jsonl`: how each rewrite treats the
  target (dropped / excluded / mentioned / depicted). `cue_type.jsonl`: cue
  word categories per prompt. `notarget_prompts.jsonl`: the prompts used
  for the unprompted appearance rate $u$ (Section 5.3), one per OverReal-Gen
  prompt, with the target replaced by a blank (`___`).
- `overreal_det/metadata.jsonl`: one row per image (image_id, prompt, target,
  family, generator, seed, prompt condition, both annotators' labels).
  `det_split.jsonl`: gold / ambiguous split with both label sets and the
  gold label. `auto_split.jsonl`: development / test split used to build and
  evaluate the automatic annotator. `eval_sample.jsonl`: the stratified sample
  of generated images behind Table 1.
- `judge_outputs/`: per-image outputs of the automatic annotator: the answer
  to each question node, the resulting label, and timing. The instantiated
  question tree is omitted to save space; it is rebuilt deterministically from
  the prompt and target by the protocol builder in `code/autoannot/common.py`
  (`final__*` = the protocol of Appendix E.1 with Claude Opus 5 or GPT-5.2;
  `__sample` = Table 1 sample, `__wild_*` = in-the-wild set; `v1`..`v7` = the
  self-evolution rounds on the development split; `presence__*__notarget` =
  target presence on the target-removed prompts for the unprompted appearance
  rate).
- `metrics/`: per-image CLIPScore, VQAScore, PickScore, HPSv2 and the two LLM
  judge ratings.
- `manifests/`: generation manifests per system and prompt condition.

## code/

- `gen/`: generation runners for the open-weight models (`run_local.py`) and
  the API systems, the prompt expanders and the target-removed prompt builder.
- `metrics/`: conventional metrics (`run_conventional.py`), LLM judge
  (`run_lj_*.py`), the evaluation sample and the main-table filler.
- `autoannot/`: the cascade annotator (`common.py` holds every protocol
  version), the development/test split, the runner and the evaluation
  against the human labels (`eval_auto.py`).
- `wild/`: mining and classification of the in-the-wild prompts.
- `annotation/`: the human annotation interface.
- `mechanism/`: plain-mention controls (`pairs.jsonl`), encoder probes
  (`probe.py`, `ask_encoder.py`), attention recording (`attn_*.py`,
  `analyze_attn.py`), and the attention intervention (`intervene_*.py`,
  design and results in `INTERVENTION.md`, `results/intervention_summary.md`).
- `build_overreal.py`, `build_family1_negbench.py`: assembling the benchmark.

## Environment

Python 3.10, torch 2.11, diffusers 0.39, transformers 5.8. Set `HF_HOME` to
the model cache and `REPO` to this directory where scripts refer to them.
Model versions: FLUX.1-dev, Qwen-Image, SD3.5-Medium/Large, OmniGen2 (open);
GPT-Image-1.5, Ideogram v3, gemini-2.5-flash-image (API); judges Claude
Opus 5 and gpt-5.2-2025-12-11; local VLM Qwen2.5-VL-7B-Instruct.
